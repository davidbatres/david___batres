######################### Documentación Interna #########################
# Autor: David Batres Fernando Rosales
# Lenguaje: Python
# Fecha: 04-24-2024
# Este programa fue diseñado para contar una historia interactiva con el usuario
# esta enfocado en el uso de los niños para promover la lectura, se realizaron
# dibujos utilizando la libreria turtle para acompañar la historia.

import turtle
import random

tur = turtle.Turtle()
tur.speed(1000)
turtle.setup(width=1000, height=800)

def teleport(coordenadas):
    tur.penup()
    tur.goto(*coordenadas)
    tur.pendown()

def linea(tamaño,coordenadas,angulo,color):
    teleport(coordenadas)
    tur.color(color)
    tur.setheading(angulo)
    tur.forward(tamaño)

def figure(tamaño,lados,coordenadas,angulo,color,rellenar = True):
    tur.color(color)
    teleport(coordenadas)
    tur.setheading(angulo)
    if rellenar == True: tur.begin_fill()
    for i in range(lados):
        tur.forward(tamaño)
        tur.right(360/lados)
    if rellenar == True: tur.end_fill()

def lobo(coordenadas,tamaño): 
    x,y=coordenadas[0],coordenadas[1]
    figure(tamaño*1.3,3,(x,y-tamaño*1.1),60,"#434343")
    figure(tamaño*.4,3,(x+tamaño*1,y-tamaño*.8),15,"#434343")
    figure(tamaño,3,coordenadas,0,"gray")
    figure(tamaño/2,3,coordenadas,60,"black")
    figure(tamaño/2,3,(x+tamaño/2,y),60,"black")
    linea(tamaño*.3,(x+tamaño*.4,y-tamaño*.4),45+90,"black")
    linea(tamaño*.3,(x+tamaño*.6,y-tamaño*.4),45,"black")
    figure(tamaño*.015,45,(x+tamaño*.5,y-tamaño*.7),0,"black")

def cerdito(coordenadas,tamaño):
    x,y=coordenadas[0],coordenadas[1]
    figure(tamaño*.08,45,(x,y-tamaño*.4),0,"#cc99a2")
    figure(tamaño*.06,45,coordenadas,0,"pink")
    figure(tamaño*.02,45,(x-tamaño*0.3,y+tamaño*.15),0,"pink")
    figure(tamaño*.02,45,(x+tamaño*0.3,y+tamaño*.15),0,"pink")
    figure(tamaño*.02,45,(x,y-tamaño*.43),0,"#FED5D5")
    figure(tamaño*.005,45,(x-tamaño*.06,y-tamaño*.55),0,"#090909")
    figure(tamaño*.005,45,(x+tamaño*.06,y-tamaño*.55),0,"#090909")
    figure(tamaño*.01,45,(x-tamaño*.12,y-tamaño*.25),0,"black")
    figure(tamaño*.01,45,(x+tamaño*.12,y-tamaño*.25),0,"black")
    
def casa(coordenadas,tamaño,color):
    x,y=coordenadas[0],coordenadas[1]
    figure(tamaño,4,coordenadas,0,color)
    figure(tamaño,3,coordenadas,60,"black")
    figure(tamaño*0.23,4,(x+tamaño*.7,y-tamaño*.55),0,"brown")
    figure(tamaño*0.23,4,(x+tamaño*.7,y-tamaño*.7),0,"brown")
    figure(tamaño*0.004,45,(x+tamaño*.87,y-tamaño*.7),0,"white")

def casa_destruida(coordenadas,tamaño,color):
    x,y=coordenadas[0],coordenadas[1]
    for i in range(30):
        xa = random.randint(int(x),int(x+tamaño))
        ya = random.randint(int(y-(tamaño//1.4)),int(y))
        aa = random.randint(0,90)
        tt= random.randint(int(tamaño*0.08),int(tamaño*0.29))
        figure(tt,4,(xa,ya),aa,color)
        figure(tt,4,(xa,ya),aa,"black",False)

def escribir(coordenadas,texto,font):
    teleport(coordenadas)
    tur.write(texto,font=font)

def part1(nombre):
    escribir((-250,340),"Las Casas de Paja, Madera y Ladrillo",("Arial",22,"bold"))
    linea(900,(-450,310),0,"black")
    linea(900,(-450,-270),0,"black")
    escribir((-400,-370),"Había una vez tres cerditos que decidieron construir cada uno su casa. El primer cerdito construyó su casa \nde paja muy rápido para poder descansar y jugar. El segundo cerdito construyó su casa de madera, un \npoco más fuerte que la de paja. El tercer cerdito, más trabajador, decidió construir su casa de ladrillo, \nllevándole más tiempo pero quedando mucho más segura. Pero había un lobo llamado "+str(nombre)+"",("Arial",12,"normal"))
    casa((-400,50),200,"gold")
    cerdito((-400,0),100)
    casa((-80,70),160,"#b88467")
    cerdito((-80,10),75)
    casa((200,50),200,"gray")
    cerdito((200,0),100)

def part2(nombre):
    escribir((-370,340),"La Visita del Lobo",("Arial",22,"bold"))
    linea(900,(-450,310),0,"black")
    linea(900,(-450,-270),0,"black")
    escribir((-400,-360),"Un día, un lobo "+str(nombre)+" hambriento llegó a la casa de paja y tocó la puerta. Al no dejarlo entrar, el lobo "+str(nombre)+" sopló y \nla casa de paja se derrumbó. El primer cerdito corrió hacia la casa de madera de su hermano.",("Arial",12,"normal"))
    casa_destruida((-420,100),380,"gold")
    lobo((180,50),200)

def part3(nombre):
    escribir((-380,340),"El Segundo Intento del Lobo",("Arial",22,"bold"))
    linea(900,(-450,310),0,"black")
    linea(900,(-450,-270),0,"black")
    escribir((-400,-360),"El lobo "+str(nombre)+" alcanzó a los dos cerditos en la casa de madera y volvió a soplar. La estructura no fue suficiente \npara resistir el aliento del lobo "+str(nombre)+" y también se derrumbó. Los dos cerditos corrieron asustados hacia \nla casa de ladrillos.",("Arial",12,"normal"))
    cerdito((-400,30),140)
    cerdito((-260,40),150)
    casa_destruida((-300,100),390,"#b88467")
    lobo((180,50),170)

def part4(nombre):
    escribir((-380,340),"La Seguridad de la Casa de Ladrillos",("Arial",22,"bold"))
    linea(900,(-450,310),0,"black")
    linea(900,(-450,-270),0,"black")
    escribir((-400,-360),"Los tres cerditos se refugiaron en la casa de ladrillos. Cuando el lobo "+str(nombre)+" intentó soplar esta casa, no pudo \nderrumbarla, por más que lo intentó. Exhausto y frustrado, el lobo "+str(nombre)+" finalmente desistió y se fue.",("Arial",12,"normal"))
    casa((-350,50),250,"gray")
    lobo((140,50),190)

def part5(nombre):
    escribir((-380,340),"La Celebración de los Cerditos",("Arial",22,"bold"))
    linea(900,(-450,310),0,"black")
    linea(900,(-450,-270),0,"black")
    escribir((-400,-360),"Tras la partida del lobo "+str(nombre)+", los tres cerditos celebraron su victoria gracias al esfuerzo y la dedicación \ndel tercer cerdito. Decidieron que en adelante construirían todo con ladrillos para estar seguros.",("Arial",12,"normal"))
    casa((-400,50),200,"gray")
    cerdito((-400,0),100)
    casa((-80,70),160,"gray")
    cerdito((-80,10),75)
    casa((200,50),200,"gray")
    cerdito((200,0),100)

nombre = ""
while nombre == "": nombre = input("Ingrese Su nombre: ")
edad = ""
while edad == "":
    try:
        edad = int(input("Ingrese su edad: "))
    except:
        print("Solo puede ingresar un número")
color = ""
while color == "":
    try:
        color = int(input("1) Azul\n2) Verde\n3) Rosa\n4) Amarillo\n5) Rojo\nIngrese su color favorito: "))
    except:
        print("Solo puede ingresar un número")

parte = 0
while parte != 6:
    parte = 0
    print("\n1)Parte #1\n2)Parte #2\n3)Parte #3\n4)Parte #4\n5) Parte #5\n6) SALIR")
    while parte == 0:
        try:
            parte = int(input("Ingrese la parte que desee ver: "))
            if parte<1 and parte>5:
                parte = 0
        except:
            print("Solo puede ingresar un número entre 1 y 5")

    if parte == 1:
        tur.clear()
        part1(nombre)
    elif parte == 2:
        tur.clear()
        part2(nombre)
    elif parte == 3:
        tur.clear()
        part3(nombre)
    elif parte == 4:
        tur.clear()
        part4(nombre)
    elif parte == 5:
        tur.clear()
        part5(nombre)
turtle.bye()
if parte!=6: turtle.done()